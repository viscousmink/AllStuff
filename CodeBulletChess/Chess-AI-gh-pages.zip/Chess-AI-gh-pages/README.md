# Chess-AI
Using minimax i created a chess AI
